
var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
productModel = mongoose.model('productModel');
productCategotyModel = mongoose.model('productCategoryModel');
userModel = mongoose.model('userModel');
var prodcutCtrl = require("../api/controller");


router.post('/login', prodcutCtrl.login);
router.post('/register',prodcutCtrl.register);
router.post('/getAllProduct', prodcutCtrl.getAllProduct);
router.post('/addNewProduct', prodcutCtrl.addNewProduct);
router.post('/addNewCategory', prodcutCtrl.addNewCategory);
router.post('/getProductById', prodcutCtrl.getProductById);
router.post('/updateProduct', prodcutCtrl.updateProduct);
router.post('/deleteProduct', prodcutCtrl.deleteProduct);
router.get('/getAllProductCategory', prodcutCtrl.getAllProductCategory);
router.post('/fileUpload', prodcutCtrl.fileUpload);



module.exports = router;

