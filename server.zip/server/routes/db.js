
var mongoose = require('mongoose');
mongoose.Promise = global.Promise;

require('../models/productModel');
require('../models/productCategoryModel');
require('../models/userModel');


var uri = 'mongodb://localhost:27017/simfProject';


mongoose.connect(uri,{ useNewUrlParser: true ,useUnifiedTopology: true }, function(error) {
  if(error){
    console.log('connection failed!')
  }else{
    console.log("Database connected successfully!");
  }
});