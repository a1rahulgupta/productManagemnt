
var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var userModelSchema = Schema({

    email: { type: String, required: true },
    password: { type: String, required: true },
    verifyToken: { type: String, default: '' },
    isDelete: { type: Boolean, default: false }

});
var userModel = mongoose.model('userModel', userModelSchema);

module.exports = userModel;