
var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var productSchema = Schema({
    name: { type: String, required: true },
    image: { type: String},
    categoryName : {type: String},
    categoryId: { type: Schema.Types.ObjectId, ref: 'productCategoryModel' },
    price: { type: String},
    discount: { type: String},
    netPrice : {type: String},
    description: {type: String},
    isDelete:{ type: Boolean, default: false}

}, {
    timestamps: true
});



var productModel = mongoose.model('productModel', productSchema);

module.exports = productModel;