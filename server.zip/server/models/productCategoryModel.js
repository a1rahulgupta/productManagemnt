
var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var productCategorySchema = Schema({
    categoryName: { type: String, required: true },
    isDelete:{ type: Boolean, default: false}
}, {
    timestamps: true
});



var productCategoryModel = mongoose.model('productCategoryModel', productCategorySchema);

module.exports = productCategoryModel;