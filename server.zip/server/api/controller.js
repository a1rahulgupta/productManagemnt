var express = require('express');
var mongoose = require('mongoose');
productModel = mongoose.model('productModel');
productCategoryModel = mongoose.model('productCategoryModel');
userModel = mongoose.model('userModel')
var formidable = require('formidable');
var jwt = require('jsonwebtoken');
const fs = require('fs');
var path = require('path');
var waterfall = require('async-waterfall');

exports.register = function (req, res) {
    var finalResponse = {};
    var userObj = {
        email: req.body.email,
        password: req.body.password

    };
    if (!userObj.email || !userObj.password) {
        res.json({
            code: 400,
            data: {},
            message: "Required Fields is missing"
        });
    } else {
        waterfall([
            function (callback) {
                userModel.findOne({ email: userObj.email, password: userObj.password, isDelete: false }, function (err, userExist) {
                    if (err) {
                        callback(err, false);
                    } else {
                        if (userExist) {
                            res.json({
                                code: 400,
                                data: {},
                                message: "This user is already exist. please try again with different user."
                            });
                        } else {
                            callback(null, finalResponse);
                        }
                    }
                });
            },

            function (finalResponse, callback) {
                var obj = {
                    email: userObj.email,
                    password: userObj.password
                };

                var userRecord = new userModel(obj);
                userRecord.save(function (err, userData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        finalResponse.userData = userData;
                        callback(null, finalResponse);
                    }
                });

            }
        ], function (err, data) {
            console.log(err,data)
            if (err) {
                res.json({
                    code: 201,
                    data: {},
                    message: "Internal Error"
                });
            } else {
                res.json({
                    code: 200,
                    data: data,
                    message: "User Register Successfully"
                });
            }
        })
    }
}

exports.login = function (req, res) {
    var finalResponse = {};
    var condition = {};
    finalResponse.userData = {}
    var userObj = {
        email: req.body.email,
        password: req.body.password
    };
    if (!userObj.email || !userObj.password) {
        res.json({
            code: 400,
            data: {},
            message: "Required Fields is missing"
        });
    } else {
        waterfall([
            function (callback) {
                condition.email = userObj.email;
                condition.password = userObj.password;
                userModel.findOne(condition).exec(function (err, userData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        if (!userData) {
                            res.json({
                                code: 406,
                                data: {},
                                message: "You have entered Invalid Username and Password"
                            });
                        } else {
                            const JwtToken = jwt.sign({
                                email: userData.email,
                                _id: userData._id
                            },
                                'secret',
                                {
                                    expiresIn: 60 * 60 * 24 * 15
                                });
                            finalResponse.token = JwtToken;
                            finalResponse.userData = userData;
                            callback(null, finalResponse);
                        }
                    }
                })
            }
        ], function (err, data) {
            if (err) {
                res.json({
                    code: 400,
                    data: {},
                    message: "Internal Error"
                });
            } else {
                res.json({
                    code: 200,
                    data: data,
                    message: "Login Successfully"
                });
            }
        });
    }
}

exports.getAllProduct = function (req, res) {
    var finalResponse = {};
    var orgData = {};
    var count = req.body.count ? req.body.count : 0;
    var skip = req.body.count * (req.body.page - 1);
    waterfall([
        function (callback) {

            var condition = {};
            condition.isDelete = false;
            var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
            if (searchText != undefined && searchText != 'undefined') {
                condition.$or = [{
                        'name': new RegExp(searchText, 'gi')
                    },
                    {
                        'categoryInfo.categoryName': new RegExp(searchText, 'gi')
                    },
                ];
            }
            if (req.body.lowestPrice && req.body.highestPrice) {
                var netPriceFrom = req.body.lowestPrice;
                var netPriceTo = req.body.highestPrice;
                condition.$and = [{
                        netPrice: {
                            $gte: netPriceFrom
                        }
                    },
                    {
                        netPrice: {
                            $lte: netPriceTo
                        }
                    }
                ];
            }
            var aggregate = [
                {
                    $lookup: {
                        from: 'productcategorymodels',
                        localField: "categoryId",
                        foreignField: "_id",
                        as: "categoryInfo"
                    }
                },
                {
                    $unwind: "$categoryInfo"
                },
                {
                    $match: condition
                },
            ];
            var project = {
                $project: {
                    "_id": "$_id",
                    "name": "$name",
                    "image": "$image",
                    "categoryName": "$categoryInfo.categoryName",
                    "price": "$price",
                    "discount": "$discount",
                    "netPrice": "$netPrice",
                    "description": "$description"
                }
            };

            aggregate.push(project);
            var countQuery = [].concat(aggregate);
            aggregate.push({
                $sort: {"_id": -1}
            });
            aggregate.push({
                $skip: parseInt(skip)
            });
            aggregate.push({
                $limit: parseInt(count)
            });
            productModel.aggregate(aggregate).then(function (productData) {
                var data = {};
                data.data = productData;
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                productModel.aggregate(countQuery).then(function (dataCount) {
                    var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                    data.total_count = cnt;
                    callback(null, data);
                });
            }).catch(function (err) {
                callback(err, false);
            });
        },
    ], function (err, data) {
        console.log(err,data)
        if (err) {
            res.json({
                code: 201,
                data: {},
                message: "Internal Server Error"
            });
        } else {
            res.json({
                code: 200,
                data: data,
                message: "Data found successfully"
            });
        }
    }
    )
}

exports.addNewProduct = function (req, res) {
    var finalResponse = {};
    finalResponse.roleData = {};
    var productObj = {
        name: req.body.name,
        image: req.body.image,
        categoryId: req.body.categoryId,
        price: req.body.price,
        discount: req.body.discount,
        netPrice: req.body.netPrice,
        description: req.body.description

    };
    if (!productObj.name || !productObj.categoryId || !productObj.price || !productObj.discount || !productObj.netPrice || !productObj.description) {
        res.json({
            code: 400,
            data: {},
            message: "Required Fields is missing"
        });
    } else {
        waterfall([
            function (callback) {
                productModel.findOne({ name: productObj.name, isDelete: false }, function (err, productExist) {
                    if (err) {
                        callback(err, false);
                    } else {
                        if (productExist) {
                            res.json({
                                code: 400,
                                data: {},
                                message: "This product is already exist. please try again with different product."
                            });
                        } else {
                            callback(null, finalResponse);
                        }
                    }
                });
            },

            function (finalResponse, callback) {
                var obj = {
                    name: productObj.name,
                    image: productObj.image,
                    categoryId: productObj.categoryId,
                    price: productObj.price,
                    discount: productObj.discount,
                    netPrice: productObj.netPrice,
                    description: productObj.description
                };

                var productRecord = new productModel(obj);
                productRecord.save(function (err, productData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        finalResponse.productData = productData;
                        callback(null, finalResponse);
                    }
                });

            }
        ], function (err, data) {
            console.log(err,data)
            if (err) {
                res.json({
                    code: 201,
                    data: {},
                    message: "Internal Error"
                });
            } else {
                res.json({
                    code: 200,
                    data: data,
                    message: "Product Added Successfully"
                });
            }
        })
    }
}

exports.addNewCategory = function (req, res) {
    var finalResponse = {};
    var categoryObj = {
        categoryName: req.body.categoryName

    };
    if (!categoryObj.categoryName) {
        res.json({
            code: 400,
            data: {},
            message: "Required Fields is missing"
        });
    } else {
        waterfall([
            function (callback) {
                productCategoryModel.findOne({ categoryName: categoryObj.categoryName, isDelete: false }, function (err, categoryExist) {
                    if (err) {
                        callback(err, false);
                    } else {
                        if (categoryExist) {
                            res.json({
                                code: 400,
                                data: {},
                                message: "This category is already exist. please try again with different category."
                            });
                        } else {
                            callback(null, finalResponse);
                        }
                    }
                });
            },

            function (finalResponse, callback) {
                var obj = {
                    categoryName: categoryObj.categoryName,
                };

                var categoryRecord = new productCategoryModel(obj);
                categoryRecord.save(function (err, categoryData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        finalResponse.categoryData = categoryData;
                        callback(null, finalResponse);
                    }
                });

            }
        ], function (err, data) {
            if (err) {
                res.json({
                    code: 201,
                    data: {},
                    message: "Internal Error"
                });
            } else {
                res.json({
                    code: 200,
                    data: data,
                    message: "Category Added Successfully"
                });
            }
        })
    }
}

exports.getProductById = function (req, res) {
    var finalResponse = {};
    finalResponse.productData = {};
    waterfall([
        function (callback) {
            productModel.findOne({ _id: mongoose.Types.ObjectId(req.body.ProductId) }).populate({ path: 'categoryId', select: 'categoryName' }).exec(function (err, productData) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.productData = productData;
                    callback(null, finalResponse);
                }
            });
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: 201,
                data: {},
                message: "Internal Error"
            });
        } else {
            res.json({
                code: 200,
                data: data,
                message: "Record Found Successfully"
            });
        }
    });

}

exports.updateProduct = function (req, res) {
    var finalResponse = {};
    var productId = mongoose.Types.ObjectId(req.body.id);
    waterfall([
        function (callback) {
            productModel.findOneAndUpdate({
                _id: productId
            }, {
                $set: {
                    productId: req.body.id,
                    name: req.body.name,
                    image: req.body.image,
                    categoryName: req.body.categoryName,
                    categoryId: req.body.categoryId,
                    price: req.body.price,
                    discount: req.body.discount,
                    netPrice: req.body.netPrice,
                    description: req.body.description

                }
            }, function (err, productData) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            });
        }

    ], function (err, data) {
        if (err) {
            res.json({
                code: 201,
                data: {},
                message: "Internal Error"
            });
        } else {
            res.json({
                code: 200,
                data: {},
                message: "Record updated successfully!"
            });
        }
    });
}

exports.deleteProduct = function (req, res) {
    var finalResponse = {};
    waterfall([
        function (callback) {
            productModel.findOneAndUpdate({
                _id: req.body.productId
            }, {
                $set: {
                    isDelete: true,
                }
            }, function (err, productData) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            });
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: 201,
                data: {},
                message: "Internal Error"
            });
        } else {
            res.json({
                code: 200,
                data: {},
                message: "Record deleted successfully!"
            });
        }
    });
}

exports.getAllProductCategory = function (req, res) {
    productCategoryModel.find({
        isDelete: false
    }, function (err, categoryData) {
        if (err) {
            res.json({
                code: 201,
                data: {},
                message: "Internal Error"
            })
        } else {
            res.json({
                code: 200,
                data: categoryData
            });
        }
    }).catch(function (err) {
        res.json({
            code: 201,
            data: {},
            message: "Internal Error"
        })

    });
}

exports.fileUpload = function (req, res) {
    let form = new formidable.IncomingForm();
    form.parse(req, (err, fields, files) => {
        console.log(err)
        var oldpath = files.file.path;
        var newpath = __dirname + '/uploads/' + files.file.name;
        fs.rename(oldpath, newpath, (err) => {
            console.log(err)
            if (err) return res.send({ message: err, status: 0 });
            else return res.send({ message: 'File uploaded successfully!', status: 1, fileName: files.file.name, filePath: 'http://localhost:3001/uploads/' + files.file.name });
        });
    });
};
