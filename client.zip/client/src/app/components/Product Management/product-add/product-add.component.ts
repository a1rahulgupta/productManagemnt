import { Component, OnInit, Inject } from '@angular/core';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { RouterModule, Routes, Router, ActivatedRoute } from '@angular/router';
import { ValidationService } from '../../../services/config/config.service';
import { ProductService } from '../../../services/product/product.service';
import { routerTransition } from '../../../services/config/config.service';

import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-product-add',
  templateUrl: './product-add.component.html',
  styleUrls: ['./product-add.component.scss']
})
export class ProductAddComponent implements OnInit {
  productAddForm: FormGroup;
  productId: any;
  prdctData: any = {};
  categoryData: any = [];
  public imageUrl = 'http://localhost:3001/uploads/';
  constructor(private formBuilder: FormBuilder, private router: Router, private route: ActivatedRoute, private productService: ProductService, private toastr: ToastrService) {
    this.route.params.subscribe(params => {
			this.productId = params['id'];
			// check if ID exists in route & call update or add methods accordingly
			if (this.productId && this.productId !== null && this.productId !== undefined) {
				this.getProductDetails(this.productId);
			} else {
				this.createForm(null);
			}
		});
  }
  ngOnInit() {
this.getAllCategoryName();
  }

  doRegister() {
		if (this.productId && this.productId !== null && this.productId !== undefined) {
      this.productAddForm.value.id = this.productId;
      this.updateProduct();
		} else {
      this.productId = null;
      this.addNewProduct();
    }
}

addNewProduct(){
  this.productAddForm.value.image  = this.prdctData.productImage;
  let netPrice = this.productAddForm.value.price - (this.productAddForm.value.price * this.productAddForm.value.discount /100);
  this.productAddForm.value.netPrice = netPrice.toFixed(2)
  this.productService.addNewProduct(this.productAddForm.value).subscribe((res: any) => {	
    if (res.code === 200) {
      this.toastr.success(res.message, 'Success');
      this.router.navigate(['/list']);
    } else {
      this.toastr.error(res.message, 'Failed');
    }
})
}
updateProduct(){
  this.productAddForm.value.image  = this.prdctData.productImage;
  let netPrice = this.productAddForm.value.price - (this.productAddForm.value.price * this.productAddForm.value.discount /100);
this.productAddForm.value.netPrice = netPrice.toFixed(2)
  this.productService.updateProduct(this.productAddForm.value).subscribe((result) => {
    const rs = result;
    if (rs.code === 200) {
      this.router.navigate(['/list']);
      this.toastr.success("success",rs.message);
    } else {
      this.toastr.error(rs.message);
    }
  });
}
  getProductDetails(ProductId){
    this.productService.getProductById({ProductId:ProductId}).subscribe((result) => {
      const rs = result;
      if (rs.code === 200) {
        this.createForm(rs.data);
      } else {
        this.toastr.error(rs.message);
      }
    });
  }



  createForm(data) {
    if (data === null) {
      this.productAddForm = this.formBuilder.group({
        name: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(50)]],
        description: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(500)]],
        price: ['', [Validators.required]],
        discount: ['', [Validators.required, Validators.required]],
        netPrice: [''],
        categoryId:[''],
        image:['']
      });
    } else {
      
      this.prdctData.productImage = data.productData.image
      this.productAddForm = this.formBuilder.group({
        name: [data.productData.name, [Validators.required, Validators.minLength(5), Validators.maxLength(50)]],
        description: [data.productData.description, [Validators.required, Validators.minLength(5), Validators.maxLength(500)]],
        price: [data.productData.price, [Validators.required]],
        discount: [data.productData.discount, [Validators.required]],
        netPrice: [data.productData.netPrice, []],
        categoryId:[data.productData.categoryId._id,[Validators.required]]
      });
    }
  }

  fileChange(e, type?) {
    let form = new FormData();
    form.append('file', e.target.files[0]);
    this.fileUpload(form, type);
  }

  fileUpload(image, type) {
      this.productService.fileUpload(image).subscribe((result) => {
      if (result.status == 1) {
        this.prdctData.productImage = result.fileName 
      }
    });
  }

  getAllCategoryName(){
    this.productService.getAllCategoryName().subscribe((result) => {
      const rs = result;
      if (rs.code === 200) {
        this.categoryData = rs.data;
      } else {
        this.toastr.error(rs.message);
      }
    });
  }

}

