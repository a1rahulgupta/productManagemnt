import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { enableProdMode } from '@angular/core';

// Modules
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
import { FilterPipe } from './pipes/filter.pipe';
// Components
import { AppComponent } from './components/index/app.component';
import { AppRoutingModule } from './app-routing.module';
import { ProductAddComponent } from './components/Product Management/product-add/product-add.component';
import { ProductListComponent } from './components/Product Management/product-list/product-list.component';
import { ProductDetailsComponent } from './components/Product Management/product-details/product-details.component';
import { ProductService } from './services/product/product.service';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { AuthService } from './services/auth/auth.service';
import { UserService } from './services/user/user.service';




@NgModule({
	declarations: [
		AppComponent,
		HomeComponent,
		ProductAddComponent,
		ProductListComponent,
		ProductDetailsComponent,
		FilterPipe,
		LoginComponent
		

	],
	imports: [
		BrowserModule,
		RouterModule,
		AppRoutingModule,
		FormsModule,
		ReactiveFormsModule,
		BrowserAnimationsModule,
		HttpClientModule,
		ToastrModule.forRoot({
			timeOut: 3000,
			positionClass: 'toast-bottom-right',
			preventDuplicates: true,
		}),
	],
	providers: [ProductService,AuthService,UserService],
	bootstrap: [AppComponent]
})

// enableProdMode();

export class AppModule { }
